/* This header file is to avoid trouble with semi-ANSI header files
   on the Convex in system version 8.0.  */

#define _PROTO(list) ()
